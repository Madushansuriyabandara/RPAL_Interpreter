package Symbols;

public class Err extends Symbol {
    public Err() {
        super("error");
    }
}