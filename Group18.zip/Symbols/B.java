package Symbols;

import java.util.ArrayList;

public class B extends Symbol {
    public ArrayList<Symbol> symbols;
    
    public B() {
        super("b");
    }
}