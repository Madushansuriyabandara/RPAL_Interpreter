package Symbols;

public class Dummy extends Rand {
    public Dummy() {
        super("dummy");
    }
}