package Symbols;

public class Uop extends Rator {
    public Uop(String data) {
        super(data);
    }
}