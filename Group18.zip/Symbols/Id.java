package Symbols;

public class Id extends Rand {
    public Id(String data) {
        super(data);
    }
    
    // override the getData method from the Rand class
    @Override
    public String getData() {
        return super.getData();
    }
}