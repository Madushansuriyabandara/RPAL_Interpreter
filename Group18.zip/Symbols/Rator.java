package Symbols;

public class Rator extends Symbol {
    public Rator(String data) {
        super(data);
    }
}