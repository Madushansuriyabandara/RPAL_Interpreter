package Symbols;

public class Bool extends Rand {
    public Bool(String data) {
        super(data);
    }
}