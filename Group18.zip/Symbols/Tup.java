package Symbols;

import java.util.ArrayList;

public class Tup extends Rand {
    public ArrayList<Symbol> symbols;
    
    public Tup() {
        super("tup");
        this.symbols = new ArrayList<Symbol>();
    }
}