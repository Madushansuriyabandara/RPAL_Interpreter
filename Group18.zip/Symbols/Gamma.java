package Symbols;

public class Gamma extends Symbol {
    public Gamma() {
        super("gamma");
    }
}