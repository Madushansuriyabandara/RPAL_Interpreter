package Symbols;

public class Beta extends Symbol {
    public Beta() {
        super("beta");
    }
}