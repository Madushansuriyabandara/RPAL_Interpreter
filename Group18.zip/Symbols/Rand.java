package Symbols;

public class Rand extends Symbol {
    public Rand(String data) {
        super(data);
    }
    
    // override the getData method from the Symbol class
    @Override
    public String getData() {
        return super.getData();
    }
}