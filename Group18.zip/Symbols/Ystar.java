package Symbols;

public class Ystar extends Symbol {
    public Ystar() {
        super("<Y*>");
    }
}