package Symbols;

public class Str extends Rand {
    public Str(String data) {
        super(data);
    }
}