package Symbols;

public class Bop extends Rator{
    public Bop(String data) {
        super(data);
    }
}