package Symbols;

public class Int extends Rand {
    public Int(String data) {
        super(data);
    }
}