package LexicalAnalyzer;

public enum TokenType {
	KEYWORD,
    IDENTIFIER,
    INTEGER,
    OPERATOR,
    STRING,
    PUNCTUATION,
    EndOfTokens
}